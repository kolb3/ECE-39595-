#include "Node.h"
#include "LinkedList.h"

LinkedList::LinkedList( ) {
   head = nullptr;
}
   
void LinkedList::addNode(Node* n) {
   n->setNext(head);
   head = n;
}

void LinkedList::print( ) {
   if (head != nullptr) {
      head->print( );
   }
}
