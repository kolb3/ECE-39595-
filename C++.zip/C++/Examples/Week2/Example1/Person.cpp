#include <string>
#include "Person.h"

Person::Person( ) {
   name = "Anne";
}

std::string Person::getName( ) {
   return name;
}
   
