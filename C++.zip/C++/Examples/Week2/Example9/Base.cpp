#include "Base.h"

Base::Base( ) {iv=0;}
