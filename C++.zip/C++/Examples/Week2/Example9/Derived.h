#ifndef DERIVED_H_
#define DERIVED_H_

#include "Base.h"

class Derived : public Base {
public:
   int iv;
   Derived( );
};
#endif /* DERIVED_H_ */
