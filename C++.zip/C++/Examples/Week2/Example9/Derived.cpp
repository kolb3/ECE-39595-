#include "Derived.h"

Derived::Derived( ) {iv = 1;}
