#include "Base.h"

#ifndef DERIVED_H_
#define DERIVED_H_
class Derived : public Base {
public:
   int iv;
   Derived( );
};
#endif /* DERIVED_H_ */
