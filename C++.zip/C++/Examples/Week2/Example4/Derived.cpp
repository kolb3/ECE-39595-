#include <iostream>
#include "Derived.h"

void Derived::m1( ) {
   std::cout << "Derived.m1" << std::endl;
}

void Derived::m2( ) {
   std::cout << "Derived.m2" << std::endl;
}
