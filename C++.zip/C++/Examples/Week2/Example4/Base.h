#ifndef BASE_H_
#define BASE_H_

class Base {

public:
   virtual void m1( );
};

#endif /* BASE_H_ */
