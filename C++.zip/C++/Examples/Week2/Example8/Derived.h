#ifndef DERIVED_H_
#define DERIVED_H_
#include "Base.h"

class Derived : public Base {

public:
   void m1( );
   virtual void m3( );
};

#endif /* DERIVED_H_ */
