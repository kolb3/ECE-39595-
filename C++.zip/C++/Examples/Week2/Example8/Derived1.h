#ifndef DERIVED1_H_
#define DERIVED1_H_
#include "Base.h"

class Derived1 : public Base {
public:
   virtual void m1( );
};
#endif /* DERIVED1_H_ */
