#ifndef DERIVED2_H_
#define DERIVED2_H_
#include "Derived1.h"

class Derived2 : public Derived1 {
public:
   virtual void m1( );
};
#endif /* DERIVED2_H_ */
