#include <iostream>
#include "Derived1.h"
 
void Derived1::m1( ) { 
   std::cout << "Derived1.m1" << std::endl; 
} 
