#include <iostream>
#include "Derived2.h"
 
void Derived2::m1( ) { 
   std::cout << "Derived2.m1" << std::endl; 
} 
