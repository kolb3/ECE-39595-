#include <string>
#include "Person.h"

std::string Person::getName( ) {
   return name;
}
   
