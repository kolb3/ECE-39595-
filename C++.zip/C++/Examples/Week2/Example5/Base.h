#ifndef BASE_H_
#define BASE_H_

class Base {

private:
   virtual void m1( );

public:
   virtual void foo(Base* b);
};

#endif /* BASE_H_ */
