#ifndef BASE_H_
#define BASE_H_

class Base {
public:
   Base( );
};
#endif /* BASE_H_ */

