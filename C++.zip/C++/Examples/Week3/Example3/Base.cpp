#include <iostream>
#include "Base.h"
Base::Base( ) {
   std::cout << "Base" << std::endl;
}
