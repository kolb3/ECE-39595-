#ifndef X_H_
#define X_H_
#include "Base.h"

class Derived : public Base {
public:
   Derived( );
   virtual ~Derived( );
};
#endif /* X_H_ */

