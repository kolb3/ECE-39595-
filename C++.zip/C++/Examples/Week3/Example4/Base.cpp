#include <iostream>
#include "Base.h"
Base::Base( ) {
   std::cout << "Base" << std::endl;
}

Base::~Base( ) {
   std::cout << "~Base" << std::endl;
}
