#include "Item.h"
#include <iostream>

int main (int argc, char *argv[]) { 

   Item *iP1 = new Item(4, 6.50);
   Item *iP2 = new Item(5, 7.50);
   iP1->print( );

}
