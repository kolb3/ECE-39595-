#include "Base.h"

int main(int argc, char* argv[ ]) {
   Base base(10, 20, 30);
   base.print( );
}
