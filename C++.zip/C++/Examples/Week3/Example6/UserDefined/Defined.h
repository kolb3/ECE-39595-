#ifndef DEFINED_H_
#define DEFINED_H_

class Defined {
public:
   int* array;
   Defined( );
   Defined(Defined&);
};
#endif /* DEFINED */
