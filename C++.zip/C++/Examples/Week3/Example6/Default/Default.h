#ifndef DEFAULT_H_
#define DEFAULT_H_

class Default {
public:
   int* array;
   Default( );
};
#endif /* DEFAULT_H_ */
